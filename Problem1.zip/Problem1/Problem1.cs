﻿using System;
using System.Collections.Generic;

namespace Problem1
{
    class Problem1
    {
        static void Main(string[] args)
        {
            int max_value = 10000000;

            List<int> fibonacci = new()
            {
                1
            };

            int latest = 2;

            while (latest < max_value)
            {
                fibonacci.Add(latest);
                latest = fibonacci[^1] + fibonacci[^2];
            }

            int final_sum = 0;
            int even_count = 0;
            foreach(int number in fibonacci)
            {
                if(number % 2 == 0)
                {
                    final_sum += number;
                    even_count += 1;
                }
            }

            Console.WriteLine($"In a fibonacci sequence where values cannot exceed {max_value}, there are {fibonacci.Count} numbers, " +
                $"{even_count} of which are even.\nThe sum of these even numbers is {final_sum}."); 

            
        }
    }
}
