﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Problem2
{
    class Problem2
    {
        static void Main(string[] args)
        {
            string[] values_from_file = File.ReadAllLines(Path.Combine(Environment.CurrentDirectory, "problem2.txt"));
            List<int> numbers = new(Array.ConvertAll(values_from_file, int.Parse));

            numbers.Sort();

            int number1 = numbers[0];
            int number2 = numbers[^1];

            int forwardCounter = 0;
            int sum = number1 + number2;

            while(sum != 2424 || forwardCounter > numbers.Count - 1)
            {
                number1 = numbers[forwardCounter];

                int backwardCounter = numbers.Count - 1;
                sum = number1 + numbers[backwardCounter];

                while (sum > 2424 || backwardCounter < 0)
                {
                    number2 = numbers[backwardCounter];
                    sum = number1 + number2;
                    backwardCounter--;
                }
                forwardCounter++;
            }

            Console.WriteLine($"Number1: {number1}\nNumber2: {number2}\nSum: {sum}\nProduct: {number1 * number2} ");
        }
    }
}
